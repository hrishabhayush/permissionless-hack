interface WalletConnection {
    website: string;
    walletAddress: string;
    walletType: 'solana' | 'ethereum';
    timestamp: number;
    connectionMethod: string;
}
interface ChatGPTSession {
    query: string;
    sources: string[];
    timestamp: number;
    website: string;
}
declare global {
    interface Window {
        solana?: {
            isConnected: boolean;
            publicKey?: {
                toString(): string;
            };
            connect(): Promise<any>;
            disconnect(): Promise<void>;
            on?(event: string, callback: Function): void;
            isPhantom?: boolean;
        };
        phantom?: {
            solana?: any;
        };
    }
}
export declare class WalletTracker {
    private walletConnections;
    private chatgptSessions;
    private solanaWallet;
    constructor();
    private init;
    private loadStoredData;
    private trackWalletConnection;
    private trackChatGPTSession;
    private setupSolanaWalletMonitoring;
    private setupWalletUIMonitoring;
    private setupNetworkMonitoring;
    private setupChatGPTMonitoring;
    getConnectionForWebsite(website: string): WalletConnection | null;
    getRecentChatGPTSessions(hours?: number): ChatGPTSession[];
}
export type { WalletConnection, ChatGPTSession };
//# sourceMappingURL=wallet-tracker.d.ts.map