export {};
//# sourceMappingURL=background.d.ts.map