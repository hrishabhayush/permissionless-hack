declare const backgroundTestUser: {
    username: string;
    walletAddress: string;
};
declare function generateReferralParam(userId: string): string;
declare function testExtension(): void;
//# sourceMappingURL=background.d.ts.map